package MODEL;



import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.channels.ServerSocketChannel;
import java.util.Scanner;

import javax.swing.JLabel;

import CONTROLLER.Controller;
import VIEW.FinestraConnessione;
import VIEW.FinestraGioco;
import VIEW.FinestraMosse;

public class MyThread extends Thread implements ActionListener{
	
	private FinestraConnessione f;
	private FinestraGioco f2;
	Socket s;
	Scanner in;
	PrintWriter out;
	Gestione g;
	Controller c;
	FinestraMosse f4;
	String t;

	
	public MyThread(Socket s,Gestione g,FinestraGioco f2,Controller c,FinestraMosse f4) {
		this.g=g;
		this.s=s;
		this.c=c;
		this.f2=f2;
		this.f4=f4;
		this.f4.getBtnHit().addActionListener(this);
		this.f4.getBtnStand().addActionListener(this);
		
		System.out.println("$ciaooo");
		try {
			out = new PrintWriter(s.getOutputStream(), true);
			in = new Scanner(s.getInputStream());
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		//mando le carte del client
		//out.flush();
		System.out.println("%" + c.getPath1());
		out.println(c.getPath1());
		SLEEP();
		out.flush();
		System.out.println("�$" + c.getPath2());
		out.println(c.getPath2());
		SLEEP();
		//mando le carte del server
		out.flush();
		out.println(c.getPath4());
		
		SLEEP();
		out.flush();
		out.println(c.getPath3());
		SLEEP();
		
		out.flush();
		t="turno1";
		out.println(t);
		
		/*String cc="ciao";
		try {
			cc=Ascolto();
			if(cc.equals("punta"))
				cc=Ascolto();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.f2.getLblGPuntata().setText("Puntata: "+cc);*/
	}



	
	
	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		/*try {
			this.sleep(50);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		// legge quello che arriva
		while (true) {
			
			/*String ca="ciao";
			try {
				ca=Ascolto();
			/*	if(ca.equals("punta")){
					ca=Ascolto();
					this.f2.getLblGPuntata().setText("Puntata: "+ca);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			
			while(t.equals("turno0")){
				System.out.println("sta girando turno 0");
			}
			while(t.equals("turno1")){
				String cc="ciao";
				try {
					cc=Ascolto();
					System.out.println("server riceve: "+cc);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Il server ha ricevuto: ---" + cc + "--- ");
			/*	if(cc.equals("turno0")){
					t="turno0";
				}*/
				if (cc.equals("hit") && t.equals("turno1")) {
					System.out.println("HiTT");
					String path=String.valueOf(g.Distribuzione());
					out.flush();
					out.println(path);
					
					//mostra su FinestraGioco la carta pescata
					f2.getpManoG1().add(new JLabel(c.CaricaImmagine(path+".png")));
					f2.getSG1().setViewportView(f2.getpManoG1());
					
				}
				if (cc.equals("stand")) {
					t="turno0";
					System.out.println("setto fine turno");
				}
			}
				/*if (cc.equals("dd") && t.equals("turno1")) {
					out.flush();
					out.println(g.Distribuzione());
				}*/	
			//}
		}
	}
	
	public String Ascolto() throws IOException{
		InputStreamReader isr = new InputStreamReader(s.getInputStream());
		BufferedReader in = new BufferedReader(isr);
		String sa = in.readLine();
		return sa;
	}
	
	
	public void HIT(){
		out.println(g.Distribuzione());
	}
	
	public void SLEEP(){
		try {
			this.sleep(50);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public InetAddress getIpAddress(){
		return s.getInetAddress();
		
	}


	@Override
	public void actionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		
		//Pulsante Hit
			if(evt.getSource()==f4.getBtnHit()){
				//System.out.println("T � = "+t);
				if(t.equals("turno0")){
				
					String path=String.valueOf(g.Distribuzione());
					f2.getpManoDealer().add(new JLabel(c.CaricaImmagine(path+".png")));
					f2.getSDealer().setViewportView(f2.getpManoDealer());
					f4.getpCarte().add(new JLabel(c.CaricaImmagine(path+".png",50,70)));
					f4.getsCarte().setViewportView(f4.getpCarte());
					
					
					out.flush();
					out.println("turno0");
					SLEEP();
					out.flush();
					out.println("ServerHIT");
					SLEEP();
					out.flush();
					out.println(path);
					
				}
			}
			//Pulsante Stand
			if(evt.getSource()==f4.getBtnStand()){
				System.out.println("turno1");
				out.flush();
				out.println("stand");
			}
		
	}

	
	
	
}
