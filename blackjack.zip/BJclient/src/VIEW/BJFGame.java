package VIEW;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

public class BJFGame extends JFrame {

	private JPanel contentPane;
	private JLabel lblBg;
	private JScrollPane sDealer;
	private JPanel pManoDealer;
	private JScrollPane sGiocatore;
	private JPanel pManoGiocatore;

	public BJFGame() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 928, 494);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		sDealer = new JScrollPane();
		sDealer.setBounds(307, 22, 302, 94);
		contentPane.add(sDealer);
		
		pManoDealer = new JPanel();
		sDealer.setViewportView(pManoDealer);
		
		sGiocatore = new JScrollPane();
		sGiocatore.setBounds(307, 310, 302, 100);
		contentPane.add(sGiocatore);
		
		pManoGiocatore = new JPanel();
		sGiocatore.setViewportView(pManoGiocatore);
		
		lblBg = new JLabel("");
		lblBg.setIcon(new ImageIcon(BJFGame.class.getResource("/img/blackjack_table.png")));
		lblBg.setBounds(0, 0, 917, 469);
		contentPane.add(lblBg);
	}

	public JScrollPane getsDealer() {
		return sDealer;
	}



	public void setsDealer(JScrollPane sDealer) {
		this.sDealer = sDealer;
	}



	public JPanel getpManoDealer() {
		return pManoDealer;
	}



	public void setpManoDealer(JPanel pManoDealer) {
		this.pManoDealer = pManoDealer;
	}



	public JScrollPane getsGiocatore() {
		return sGiocatore;
	}



	public void setsGiocatore(JScrollPane sGiocatore) {
		this.sGiocatore = sGiocatore;
	}



	public JPanel getpManoGiocatore() {
		return pManoGiocatore;
	}



	public void setpManoGiocatore(JPanel pManoGiocatore) {
		this.pManoGiocatore = pManoGiocatore;
	}



	public JLabel getLblBg() {
		return lblBg;
	}

	public void setLblBg(JLabel lblBg) {
		this.lblBg = lblBg;
	}
}