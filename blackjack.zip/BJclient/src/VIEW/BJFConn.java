package VIEW;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class BJFConn extends JFrame {

	private JPanel contentPane;
	private JButton btnConnetti;
	private JLabel lblNickname;
	private JTextField textStartMoney;
	private JLabel lblIpServer;
	private JTextField textFieldIP;

	public BJFConn() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 296, 234);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnConnetti = new JButton("Connetti");
		btnConnetti.setBounds(88, 135, 89, 23);
		contentPane.add(btnConnetti);
		
		lblNickname = new JLabel("Soldi Iniziali:");
		lblNickname.setBounds(41, 30, 76, 14);
		contentPane.add(lblNickname);
		
		textStartMoney = new JTextField();
		textStartMoney.setBounds(160, 27, 86, 20);
		contentPane.add(textStartMoney);
		textStartMoney.setColumns(10);
		
		lblIpServer = new JLabel("IP server");
		lblIpServer.setBounds(41, 79, 76, 14);
		contentPane.add(lblIpServer);
		
		textFieldIP = new JTextField();
		textFieldIP.setBounds(160, 76, 86, 20);
		contentPane.add(textFieldIP);
		textFieldIP.setColumns(10);
	}

	public JButton getBtnConnetti() {
		return btnConnetti;
	}

	public void setBtnConnetti(JButton btnConnetti) {
		this.btnConnetti = btnConnetti;
	}

	public JLabel getLblNickname() {
		return lblNickname;
	}

	public void setLblNickname(JLabel lblNickname) {
		this.lblNickname = lblNickname;
	}

	public JLabel getLblIpServer() {
		return lblIpServer;
	}

	public void setLblIpServer(JLabel lblIpServer) {
		this.lblIpServer = lblIpServer;
	}

	public JTextField getTextFieldIP() {
		return textFieldIP;
	}

	public void setTextFieldIP(JTextField textFieldIP) {
		this.textFieldIP = textFieldIP;
	}

	public JTextField getTextFieldPunt() {
		return textStartMoney;
	}

	public void setTextFieldPunt(JTextField textFieldPunt) {
		this.textStartMoney = textFieldPunt;
	}
}