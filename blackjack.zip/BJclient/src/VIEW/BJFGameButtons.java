package VIEW;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;
import java.awt.SystemColor;

public class BJFGameButtons extends JFrame {

	private JPanel contentPane;
	private JButton btnHit;
	private JButton btnStand;
	private JButton btnDD;
	private JButton btnSurrender;
	private JButton buttonHelp;
	private JButton btnPunta;
	private JScrollPane sSuperManoG;
	private JTextField textFieldPunt;
	private JLabel label;
	private JLabel lblStartMoney;
	private JLabel label_1;
	private JTextPane txtpnWarn;
	private JPanel pSuperG;
	private JLabel lblPuntata;
	private JLabel label_3;

	public BJFGameButtons() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 537, 788, 241);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		btnHit = new JButton("Hit");
		btnHit.setEnabled(false);
		btnHit.setBounds(47, 11, 89, 59);
		contentPane.setLayout(null);
		contentPane.add(btnHit);
		
		btnStand = new JButton("Stand");
		btnStand.setEnabled(false);
		btnStand.setBounds(146, 11, 89, 59);
		contentPane.add(btnStand);
		
		btnDD = new JButton("Double Down");
		btnDD.setEnabled(false);
		btnDD.setBounds(245, 11, 134, 59);
		contentPane.add(btnDD);
		
		btnSurrender = new JButton("Surrender");
		btnSurrender.setEnabled(false);
		btnSurrender.setBounds(389, 11, 110, 59);
		contentPane.add(btnSurrender);
		
		buttonHelp = new JButton("");
		buttonHelp.setBounds(10, 11, 27, 23);
		buttonHelp.setIcon(new ImageIcon(BJFGameButtons.class.getResource("/javax/swing/plaf/metal/icons/Question.gif")));
		contentPane.add(buttonHelp);
		
		btnPunta = new JButton("Inizia");
		btnPunta.setBounds(509, 11, 110, 59);
		contentPane.add(btnPunta);
		
		sSuperManoG = new JScrollPane();
		sSuperManoG.setBounds(47, 81, 572, 113);
		contentPane.add(sSuperManoG);
		
		pSuperG = new JPanel();
		sSuperManoG.setViewportView(pSuperG);
		
		textFieldPunt = new JTextField();
		textFieldPunt.setBounds(629, 11, 86, 20);
		contentPane.add(textFieldPunt);
		textFieldPunt.setColumns(10);
		
		label = new JLabel("$");
		label.setBounds(725, 11, 20, 14);
		contentPane.add(label);
		
		lblStartMoney = new JLabel("");
		lblStartMoney.setHorizontalAlignment(SwingConstants.RIGHT);
		lblStartMoney.setBounds(629, 42, 86, 14);
		contentPane.add(lblStartMoney);
		
		label_1 = new JLabel("$");
		label_1.setBounds(725, 42, 20, 14);
		contentPane.add(label_1);
		
		txtpnWarn = new JTextPane();
		txtpnWarn.setForeground(Color.RED);
		txtpnWarn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtpnWarn.setEditable(false);
		txtpnWarn.setBackground(SystemColor.control);
		txtpnWarn.setText("Attenzione! Non hai abbastanza soldi per sostenere la puntata!");
		txtpnWarn.setBounds(629, 102, 134, 92);
		txtpnWarn.setVisible(false);
		contentPane.add(txtpnWarn);
		
		lblPuntata = new JLabel("");
		lblPuntata.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPuntata.setBounds(629, 67, 86, 14);
		contentPane.add(lblPuntata);
		
		label_3 = new JLabel("$");
		label_3.setBounds(725, 67, 20, 14);
		contentPane.add(label_3);
	}

	
	
	
	public JScrollPane getsSuperManoG() {
		return sSuperManoG;
	}




	public void setsSuperManoG(JScrollPane sSuperManoG) {
		this.sSuperManoG = sSuperManoG;
	}




	public JPanel getpSuperG() {
		return pSuperG;
	}




	public void setpSuperG(JPanel pSuperG) {
		this.pSuperG = pSuperG;
	}




	public JButton getBtnHit() {
		return btnHit;
	}

	public void setBtnHit(JButton btnHit) {
		this.btnHit = btnHit;
	}

	public JButton getBtnStand() {
		return btnStand;
	}

	public void setBtnStand(JButton btnStand) {
		this.btnStand = btnStand;
	}

	public JButton getBtnDD() {
		return btnDD;
	}

	public void setBtnDD(JButton btnDD) {
		this.btnDD = btnDD;
	}

	public JButton getBtnSurrender() {
		return btnSurrender;
	}

	public void setBtnSurrender(JButton btnSurrender) {
		this.btnSurrender = btnSurrender;
	}

	public JButton getButtonHelp() {
		return buttonHelp;
	}

	public void setButtonHelp(JButton buttonHelp) {
		this.buttonHelp = buttonHelp;
	}

	public JButton getBtnPunta() {
		return btnPunta;
	}

	public void setBtnPunta(JButton btnPunta) {
		this.btnPunta = btnPunta;
	}


	public JLabel getLblMoney() {
		return lblStartMoney;
	}

	public void setLblMoney(JLabel lblMoney) {
		this.lblStartMoney = lblMoney;
	}

	public JTextField getTextFieldPunt() {
		return textFieldPunt;
	}

	public void setTextFieldPunt(JTextField textFieldPunt) {
		this.textFieldPunt = textFieldPunt;
	}

	public JTextPane getTxtpnWarn() {
		return txtpnWarn;
	}

	public void setTxtpnWarn(JTextPane txtpnWarn) {
		this.txtpnWarn = txtpnWarn;
	}

	
	

	public JLabel getLblPuntata() {
		return lblPuntata;
	}

	public void setLblPuntata(JLabel lblPuntata) {
		this.lblPuntata = lblPuntata;
	}
	
}