package VIEW;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Window.Type;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.SystemColor;

public class BJFHelp extends JFrame {

	private JPanel contentPane;
	private JTextPane txtpn;

	public BJFHelp() {
		setType(Type.POPUP);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 230, 207);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtpn = new JTextPane();
		txtpn.setBackground(SystemColor.control);
		txtpn.setEditable(false);
		txtpn.setText("Hit: ricevi una carta dal banco\r\n\r\nStand: termina il tuo turno\r\n\r\nDouble Down: raddoppia la tua puntata. Puoi farlo solo una volta al turno\r\n\r\nSurrender: paga met\u00E0 della tua puntata per ritirarti dalla mano.");
		txtpn.setBounds(10, 11, 194, 158);
		contentPane.add(txtpn);
	}
}