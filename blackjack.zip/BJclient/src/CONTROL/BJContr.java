package CONTROL;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import MODEL.ClientThread;
import VIEW.*;

public class BJContr implements ActionListener, WindowListener {

	private BJFConn f;
	private BJFGame g;
	private BJFGameButtons b;
	private BJFHelp h;
	private Socket socket;
	private int puntata=0;
	private int money=10;
	private PrintWriter out;
	private Scanner in;
	ClientThread client;
	
	public BJContr (BJFConn f, BJFGame g, BJFGameButtons b, BJFHelp h) {
		this.f=f;
		this.g=g;
		this.b=b;
		this.h=h;
		
		f.getBtnConnetti().addActionListener(this);
		//b.getBtnDD().addActionListener(this);
		//b.getBtnHit().addActionListener(this);
		//b.getBtnStand().addActionListener(this);
		//b.getBtnSurrender().addActionListener(this);
		b.getButtonHelp().addActionListener(this);
		b.getBtnPunta().addActionListener(this);
		
		
	}

	//Metodo che ascolta tutte le stringhe in arrivo
	public String Ascolto() throws IOException{
		InputStreamReader isr = new InputStreamReader(socket.getInputStream());
		BufferedReader in = new BufferedReader(isr);
		String sa = in.readLine();
		return sa;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent evt) {
		
		//************ CONNESSIONE **************
		if(evt.getSource()==f.getBtnConnetti()) {
				try {
					socket = new Socket(f.getTextFieldIP().getText(), 9999);
					//socket = new Socket("192.168.4.20", 9999);
					//socket = new Socket("localhost", 9999);
					//puntata=Integer.parseInt(f.getTextFieldPunt().getText());
					f.setVisible(false);
					g.setVisible(true);
					b.setVisible(true);
					refreshPunt();

					
					b.getLblMoney().setText(f.getTextFieldPunt().getText());
					/*out = new PrintWriter(socket.getOutputStream(), true);
					out.println("punta");
					puntata = Integer.parseInt(b.getTextFieldPunt().getText());
					out.println(b.getTextFieldPunt().getText());*/
					
					//PRendo ci� che il server mi manda
					//carte del dealer
					/*String cc="ciao";
					try {
						cc=Ascolto();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("client riceve:  "+cc);
					
					g.getpManoDealer().add(new JLabel(CaricaImmagine(cc+".png")));
					g.getsDealer().setViewportView(g.getpManoDealer());
					String ca="ciao";
					try {
						ca=Ascolto();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//addCard();
					g.getpManoDealer().add(new JLabel(CaricaImmagine(ca+".png")));
					g.getsDealer().setViewportView(g.getpManoDealer());
					//addCard();
					*/
					//carte del giocatore
					
					/*String cd="ciao";
					try {
						cd=Ascolto();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//addCard();
					g.getpManoGiocatore().add(new JLabel(CaricaImmagine(cd+".png")));
					g.getsGiocatore().setViewportView(g.getpManoGiocatore());
					
					String cs="ciao";
					try {
						cs=Ascolto();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//addCard();
					g.getpManoGiocatore().add(new JLabel(CaricaImmagine(cs+".png")));
					g.getsGiocatore().setViewportView(g.getpManoGiocatore());
					
					*/
					//addCard();
					//addCard();
				} catch (Exception e) {
					System.out.println(e.getMessage()); 
			}
				client=new ClientThread(socket, g, this,b);
				client.start();
		}
		//************ FINE CONNESSIONE **************
		
		
		//************ STAND **************
		// fine turno
		if(evt.getSource()==b.getBtnStand()) {
			if (socket != null) {
				try {
					out = new PrintWriter(socket.getOutputStream(), true);
					out.println("stand");
					fineTurno();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		//************ DOUBLE DOWN **************
		// raddoppia puntata, 1/t
		if(evt.getSource()==b.getBtnDD()) {
			if (socket != null) {
				try {
					out = new PrintWriter(socket.getOutputStream(), true);
					out.println("dd");
					addCard();
					
					money=money-puntata;
					puntata=puntata*2;
					refreshPunt();
					
					fineTurno();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		//************ SURRENDER **************
		if(evt.getSource()==b.getBtnSurrender()) {
			if (socket != null) {
				try {
					out = new PrintWriter(socket.getOutputStream(), true);
					out.println("surrender");
					money=money+(puntata/2);
					refreshPunt();

					fineTurno();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		//************ PUNTATA **************
		if(evt.getSource()==b.getBtnPunta()) {/*
			if(Integer.parseInt(b.getTextFieldPunt().getText())>money) {
				b.getTxtpnWarn().setVisible(true);
			} else {
				b.getTxtpnWarn().setVisible(false);
					
				money=money-puntata;
				refreshPunt();*/
				b.getBtnPunta().setEnabled(false);
				b.getBtnHit().setEnabled(true);
				b.getBtnStand().setEnabled(true);
				//enaBtns();
			//}
		}
		
		//************ HELP **************
		if(evt.getSource()==b.getButtonHelp()) {
			if(h.isVisible()){
				h.setVisible(false);
			} else {
				h.setVisible(true);
			}
		}
	} 	//************ FINE ACTION PERFORMED **************

	public ImageIcon CaricaImmagine(String path){
		ImageIcon temp = new ImageIcon(BJFGameButtons.class.getResource("/cards/"+path));
		int width = temp.getIconWidth();
		int height = temp.getIconHeight();
		if (width > 50 || height > 70) {
			double d = 75D / Math.max(width, height);
			width = (int)Math.round(width * d);
			height = (int)Math.round(height * d);
			Image img1 = temp.getImage();
			BufferedImage img2 = new BufferedImage(
				width, height, BufferedImage.TYPE_INT_RGB
			);
			java.awt.Graphics g = img2.getGraphics();
			g.drawImage(img1, 0, 0, width, height, Color.white,null);
			
			temp = new ImageIcon(img2);
		}
		return temp;
	}
	
	public ImageIcon CaricaImmagine(String path,int larg,int alt){
		ImageIcon temp = new ImageIcon(BJFGameButtons.class.getResource("/cards/"+path));
		int width = temp.getIconWidth();
		int height = temp.getIconHeight();
		if (width > 50 || height > 70) {
			double d = 100D / Math.max(width, height);
			width = (int)Math.round(width * d);
			height = (int)Math.round(height * d);
			Image img1 = temp.getImage();
			BufferedImage img2 = new BufferedImage(
				width, height, BufferedImage.TYPE_INT_RGB
			);
			java.awt.Graphics g = img2.getGraphics();
			g.drawImage(img1, 0, 0, width, height, Color.white,null);
			
			temp = new ImageIcon(img2);
		}
		return temp;
	}
	
	
	public void enaBtns () {
		b.getBtnDD().setEnabled(true);
		b.getBtnHit().setEnabled(true);
		b.getBtnStand().setEnabled(true);
		b.getBtnSurrender().setEnabled(true);
	}
	
	public void addCard () throws IOException {
		InputStreamReader isr = new InputStreamReader(socket.getInputStream());
		BufferedReader in = new BufferedReader(isr);
		String s = in.readLine();
		
		b.getpSuperG().add(new JLabel(CaricaImmagine(s +".png")));
		b.getsSuperManoG().setViewportView(b.getpSuperG());
		
		
		//g.getPanelDealHand().add(new JLabel(CaricaImmagine(s +  ".png")));
		//g.getScrollPaneDealHand().setViewportView(g.getPanelDealHand());
	}
	
	public void refreshPunt () {
		b.getLblPuntata().setText(""+puntata);
		b.getLblMoney().setText("" + money);
	}
	
	public void fineTurno() throws IOException {
		
		b.getBtnDD().setEnabled(false);
		b.getBtnHit().setEnabled(false);
		b.getBtnPunta().setEnabled(false);
		b.getBtnStand().setEnabled(false);
		b.getBtnSurrender().setEnabled(false);
		
		String s="";
		do {
		InputStreamReader isr = new InputStreamReader(socket.getInputStream());
		BufferedReader in = new BufferedReader(isr);
		s = in.readLine();
		} while (s!="turno1");
		
		b.getBtnPunta().setEnabled(false);
	}
	
	@Override
	public void windowClosing(WindowEvent arg0) {
		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	
	

	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}