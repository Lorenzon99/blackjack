package MODEL;



import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.channels.ServerSocketChannel;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import CONTROL.BJContr;
import VIEW.BJFConn;
import VIEW.BJFGame;
import VIEW.BJFGameButtons;

public class ClientThread extends Thread implements ActionListener{
	
	private BJFConn f;
	private BJFGame f2;
	BJFGameButtons b;
	Socket s;
	Scanner in;
	PrintWriter out;
	BJContr c;
	String t;
	int ManoG=0,ManoD=0;

	
	public ClientThread(Socket s,BJFGame f2,BJContr c,BJFGameButtons b) {
		this.s=s;
		this.b=b;
		this.c=c;
		this.f2=f2;
		this.b.getBtnHit().addActionListener(this);
		this.b.getBtnStand().addActionListener(this);
		
		System.out.println("ciaooo");
		try {
			out = new PrintWriter(s.getOutputStream(), true);
			in = new Scanner(s.getInputStream());
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}



	
	
	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		// legge quello che arriva
		//carte giocatore
		String cc="ciao";
		try {
			cc=Ascolto();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("client riceve:  "+cc);
		
		f2.getpManoGiocatore().add(new JLabel(c.CaricaImmagine(cc+".png")));
		f2.getsGiocatore().setViewportView(f2.getpManoGiocatore());
		
		ManoG=ManoG+Punti(cc);
		
		b.getpSuperG().add(new JLabel(c.CaricaImmagine(cc+".png",50,70)));
		b.getsSuperManoG().setViewportView(b.getpSuperG());
		String ca="ciao";
		try {
			System.out.println("ricevo");
			ca=Ascolto();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("client riceve:  "+ca);
		f2.getpManoGiocatore().add(new JLabel(c.CaricaImmagine(ca+".png")));
		f2.getsGiocatore().setViewportView(f2.getpManoGiocatore());

		ManoG=ManoG+Punti(ca);
		
		b.getpSuperG().add(new JLabel(c.CaricaImmagine(ca+".png",50,70)));
		b.getsSuperManoG().setViewportView(b.getpSuperG());
		
		//carte del dealer
		String cs="ciao";
		try {
			cs=Ascolto();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("client riceve:  "+cs);
		f2.getpManoDealer().add(new JLabel(c.CaricaImmagine("back@2x"+".png")));
		f2.getsDealer().setViewportView(f2.getpManoDealer());
		
		ManoD=ManoD+Punti(cs);
		
		
		String cd="ciao";
		try {
			cd=Ascolto();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("client riceve:  "+cd);
		f2.getpManoDealer().add(new JLabel(c.CaricaImmagine(cd+".png")));
		f2.getsDealer().setViewportView(f2.getpManoDealer());
		
		ManoD=ManoD+Punti(cd);
		
		
		System.out.println("mano del Giocatore "+ManoG);
		System.out.println("mano del Giocatore "+ManoD);
		while(true){
		//ricevo il turno
		String cf="ciao";
		try {
			cf=Ascolto();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(cf.equals("turno1")){
			t=cf;
			System.out.println("TURNO �  "+t);
		}

				while(t.equals("turno1")){
					System.out.println("sta girando turno 1");
				}
				while(t.equals("turno0")){

					System.out.println("sta girando turno 0");
					
					String cl="ciao";
					try {
						cl=Ascolto();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("client riceve:  "+cl);
					//riceve refresh dal server
					if(cl.equals("ServerHIT")){
						String cj="ciao";
						try {
							cj=Ascolto();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						System.out.println("client riceve:  "+cj);
						f2.getpManoDealer().add(new JLabel(c.CaricaImmagine(cj+".png")));
						f2.getsDealer().setViewportView(f2.getpManoDealer());
						
						ManoD=ManoD+Punti(cj);
					}
					if(cl.equals("stand")){
						System.out.println("setto turno1");
						
						t="turno1";
					}
				
				Vinto();
				
					
				}
			}
		}
	//}
	
	public String Ascolto() throws IOException{
		InputStreamReader isr = new InputStreamReader(s.getInputStream());
		BufferedReader in = new BufferedReader(isr);
		String sa = in.readLine();
		return sa;
	}


	public void SLEEP(){
		try {
			this.sleep(50);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void Vinto(){
		if(ManoG<=21 && ManoG>ManoD){
			JOptionPane.showConfirmDialog(null, "Hai vinto! Tu: "+ManoG+" Dealer: "+ManoD, "!", JOptionPane.OK_OPTION);
			//JOptionPane.showMessageDialog(null, "Hai vinto! Tu: "+ManoG+" Dealer: "+ManoD);
		}
		if(ManoG>21){
			JOptionPane.showConfirmDialog(null, "Hai perso! Tu sopra 21: "+ManoG+" Dealer: "+ManoD, "!", JOptionPane.OK_OPTION);
			//JOptionPane.showMessageDialog(null, "Hai perso! Tu sopra 21: "+ManoG+" Dealer: "+ManoD);
		}
		if(ManoD>21){
			JOptionPane.showConfirmDialog(null, "Hai vinto! Dealer sopra 21: "+ManoG+" Tu: "+ManoD, "!", JOptionPane.OK_OPTION);
			//JOptionPane.showMessageDialog(null, "Hai vinto! Dealer sopra 21: "+ManoG+" Tu: "+ManoD);
		}
		if(ManoD<=21 && ManoD>ManoG){
			JOptionPane.showConfirmDialog(null, "Hai perso! Tu: "+ManoG+" Dealer: "+ManoD, "!", JOptionPane.OK_OPTION);
			//JOptionPane.showMessageDialog(null, "Hai perso! Tu: "+ManoG+" Dealer: "+ManoD);
		}
	}
	
	
	
	public int Punti(String card){
		int valore=0,carta=Integer.valueOf(card);
		//asso
		if(carta==10 || carta==30 || carta==50 || carta==70){
			Random randomGenerator = new Random();
		    int randomInt = randomGenerator.nextInt(10);
		    if(randomInt%2==0){
		    	valore=10;
		    }
		    else{
		    	valore=1;
		    }
		}
		//carte normali
		if(carta>10 && carta<20 || carta>30 && carta<40 || carta>50 && carta<60 || carta>70 && carta<80){
			if(carta>10 && carta<20){
				valore=carta - 9;
			}
			if(carta>30 && carta<40){
				valore=carta - 29;
			}
			if(carta>50 && carta<60){
				valore=carta - 49;
			}
			if( carta>70 && carta<80){
				valore=carta - 69;
			}
		}
		//regina, fante e re
		if(carta>19 && carta<23 || carta>39 && carta<43 || carta>59 && carta<63 || carta>79 && carta<83){
			valore=10;
		}
		
		
		return valore;
	}


	@Override
	public void actionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		
		//premo il pulsante hit
		if(evt.getSource()==b.getBtnHit()) {
			if (s != null) {
				try {
					out = new PrintWriter(s.getOutputStream(), true);
					out.flush();
					SLEEP();
					out.println("hit");
					out.flush();
					String ca="ciao";
					try {
						//System.out.println("ricevo hit");
						ca=Ascolto();
						System.out.println("riceve n "+ca);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("client riceve:  "+ca);
					f2.getpManoGiocatore().add(new JLabel(c.CaricaImmagine(ca+".png")));
					f2.getsGiocatore().setViewportView(f2.getpManoGiocatore());

					b.getpSuperG().add(new JLabel(c.CaricaImmagine(ca+".png",50,70)));
					b.getsSuperManoG().setViewportView(b.getpSuperG());
					
					
					ManoG=ManoG+Punti(ca);
					
					if(ManoG>21){
						Vinto();
					}
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		//premo il pulsante stand
		// fine turno
		if(evt.getSource()==b.getBtnStand()) {
			if (s != null) {
				//try {
					t="turno0";
					
					//out = new PrintWriter(s.getOutputStream(), true);
					out.flush();
					out.println("stand");
					
				/*} catch (IOException e) {
					e.printStackTrace();
				}*/
			}
		}
		
	}
	
	
}



	



/*out.flush();
out.println("punta");
out.flush();
out.println(b.getLblPuntata().getText());
*/
/*String ca="ciao";
try {
	ca=Ascolto();
	if(ca.equals("punta")){
		ca=Ascolto();
		this.f2.getLblGPuntata().setText("Puntata: "+ca);
	}
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

if(ca!="stand"){
	String cc="ciao";
	try {
		cc=Ascolto();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("Il server ha ricevuto: ---" + cc + "--- ");
	if (cc.equals("hit")) {
		HIT();
	}
	/*if (cc.equals("stand")) {
		out.println("0");
	}*/
	/*if (cc.equals("dd")) {
		HIT();
	}
}*/
	
	
	