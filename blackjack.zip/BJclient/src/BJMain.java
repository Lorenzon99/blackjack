import CONTROL.BJContr;
import VIEW.BJFConn;
import VIEW.BJFGame;
import VIEW.BJFGameButtons;
import VIEW.BJFHelp;

public class BJMain {

	public static void main(String[] args) {
		BJFConn f = new BJFConn();
		BJFGame g = new BJFGame();
		BJFGameButtons b = new BJFGameButtons();
		BJFHelp h = new BJFHelp();
		f.setVisible(true);
		BJContr c = new BJContr(f, g, b, h);
	}

}
